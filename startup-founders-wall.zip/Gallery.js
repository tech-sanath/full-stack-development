import React from "react";
import Profile from "./Profile";

export const Gallery = () => {
  return (
    <div style={styles.container}>
      <Profile
        name="Byju Raveendran"
        image="https://via.placeholder.com/100"
        bio="Founder of BYJU'S – world's most valued edtech company"
      />

      <Profile
        name="Ritesh Agarwal"
        image="https://via.placeholder.com/100"
        bio="Founder of OYO Rooms – started at age 19, now a global brand"
      />

      <Profile
        name="Falguni Nayar"
        image="https://via.placeholder.com/100"
        bio="Founder of Nykaa – India's first woman to lead a unicorn IPO"
      />
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    gap: "20px",
    flexWrap: "wrap",
    marginTop: "20px",
  },
};
